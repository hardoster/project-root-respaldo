<?php

namespace App\Controllers;
use App\Models\MD_NOTES;

class TecReport extends BaseController{

    public function TecReportView()
    {
        return view('TecReport');
    }


    

    
}

?>