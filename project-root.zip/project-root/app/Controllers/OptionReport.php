<?php

namespace App\Controllers;

class OptionReport extends BaseController{

    public function ViewOptionReport()
    {
        return view('optionReport');
    }

    
}

?>