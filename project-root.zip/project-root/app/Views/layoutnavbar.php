<div class="nav-bar">
    <ul>
        <li><a class="img-li-padding" href=""><img class="image-fluid logo" src="http://www.exactrack.com.sv/sis/admin/sistema/img/exactrack.png" alt="exactrack"></a></li>
        <li><a href="">Dashboard</a></li>
        <li><a href="">Administracion</a></li>
        <li style="cursor: pointer;"><a href="<?php echo site_url('/TecReport'); ?>">Informes</a></li>
        <li><a href="http://www.exactrack.com.sv/sis/admin/sistema/views/indice.php?load=monit">Monitoreo</a></li>
        <li><a href="">Mapa</a></li>
        <li><a href="<?php echo site_url('/inicio'); ?>">Registros</a></li>
    </ul>
</div>
