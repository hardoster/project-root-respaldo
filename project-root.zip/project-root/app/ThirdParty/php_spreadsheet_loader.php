// app/ThirdParty/php_spreadsheet_loader.php
<?php
require_once __DIR__ . '/../../PhpSpreadsheets/vendor/autoload.php';
?>